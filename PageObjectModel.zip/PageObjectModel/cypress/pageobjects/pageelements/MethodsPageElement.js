/// <reference types="cypress" />

const data = require("../../fixtures/testdata.json")

export default class MethodsPageElement {

    nameUser() {
        return data.nameUser;
    }

    passwordUser() {
        return data.password;
    }

    accessLogin() {
        return data.access_method;
    }

    query() {
        return data.query;
    }


}