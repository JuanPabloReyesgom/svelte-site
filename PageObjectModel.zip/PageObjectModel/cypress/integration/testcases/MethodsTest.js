/// <reference types="cypress" />


import MethodsPageActions from "../../pageobjects/pageactions/MethodsPageActions";

describe('Test methods post, get, taskQuery', () => {

    let resource = new MethodsPageActions();
    before(() => {
        globalThis.token = resource.getToken();
    })

    it('Get data', () => {
        globalThis.comparacion = resource.getDatosWithToken(token)
    })

    it('Query', () => {
        resource.taskQuery(comparacion)
    })

})